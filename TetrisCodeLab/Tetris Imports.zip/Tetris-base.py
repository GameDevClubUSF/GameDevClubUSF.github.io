import pygame
import sys
from copy import deepcopy
from random import choice

WIDTH, HEIGHT = 10, 20;
TILE = 45;
GAME_RES = (WIDTH * TILE, HEIGHT * TILE)

pygame.init()
screen = pygame.display.set_mode(GAME_RES)
pygame.display.set_caption("Tetris")

CLOCK = pygame.time.Clock()
GRID = [pygame.Rect(x * TILE, y * TILE, TILE, TILE) for x in range(WIDTH) for y in range(HEIGHT)]

# Tetromino Objects and Variables


# End Zone 


# Animation Variables 


# Fonts and texts



# Backgrounds
bg = pygame.image.load('img/bg.jpg').convert()
game_bg = pygame.image.load('img/bg2.jpg').convert()

# Other Variables
score, lines = 0, 0
scores = {0:0, 1:100, 2:300, 3:700, 4:1500}

# Functions
def check_borders():
    pass 
    # if tetromino[i].x < 0 or tetromino[i].x > WIDTH-1:
    #     return False
    # elif tetromino[i].y > HEIGHT -1 or feild[tetromino[i].y][tetromino[i].x]:          
    #     return False
    # return True

def get_record():
    try:
        with open('record.txt') as f:
            return f.readline()
    except FileNotFoundError:
        with open('record.txt', 'w') as f:
            f.write('0')

def set_record(record, score):
    rec = max(int(record), score)
    with open('record.txt', 'w') as f:
        f.write(str(rec))

# Game loop and Initializing variables
death_flag = False
record = get_record()

while True:
    dir_x = 0
    rotate = False
    screen.fill(pygame.Color("black"))

    # Controls
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        if event.type == pygame.KEYDOWN:
            pass 
            # Sideways controls (remove pass)
        elif event.type == pygame.KEYUP:
            pass
            # On release (remove pass)
            
    # X movement
    
    
    # Y movement
    
    
    # Rotating
    
    
    # Line Check / Removal
    
    
    # Rendering / Drawing sprites
    
    
    # Game over
    
    [pygame.draw.rect(screen, (40,40,40), i_rect, 1) for i_rect in GRID]
    pygame.display.update()
    CLOCK.tick(60)