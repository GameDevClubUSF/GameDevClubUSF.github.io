Difference between this fixed version and workshop version:

1. Models been added
	To Fix the culling mask problem of model appearing in front of Camera:
	- Change culling mask in Camera, Turn off one of the nodes, preferably not 1'
	- Change the mesh Instance Layer to the one that is turned off for culling mask from the Model's scene (open the model in the file system)

2. Player Script has changed,
	- `@onready var player_ray = $PlayerRay		became
	  `@onready var player_ray = $Camera3D/PlayerRay`

	- Changed mouse input transformations
	if event is InputEventMouseMotion:
			$Camera3D.rotation_degrees.x -= event.relative.y * MOUSE_SENSETIVITY
			rotation_degrees.y -= event.relative.x * MOUSE_SENSETIVITY
			$Camera3D.rotation_degrees.x = clamp($Camera3D.rotation_degrees.x, -90.0, 90.0)

3. Player object hierarchy changed
	- PlayerRay is now a child of the Camera3D

4. Replace the Capsul MeshInstance with the Model's node